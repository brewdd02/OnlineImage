$(function() {
  var $listHTML = $('ul').html();
  $('ul').append($listHTML);
});