The example under this directory is from
"JavaScript & JQuery: Interactive front-end web development"
by Jon Duckett

Chapter 7 jQuery

(1) A Basic jQuery Example:
basic-example.html
js/basic-example.js
js/jquery-1.11.0.js
css/c07.css
images/kinglogo.png

(2) Getting at Content
get-html-fragment.html
js/get-html-fragment.js
js/jquery-1.11.0.js 
css/c07.css
images/kinglogo.png

(3) Events
events.html
js/events.js
js/jquery-1.11.0.js 
css/c07.css
images/kinglogo.png

(4) Basic Effects
effects.html
js/effects.js
js/jquery-1.11.0.js 
css/c07.css
images/kinglogo.png

(5) Form Example
form.html
js/form.js
js/jquery-1.11.0.js 
css/c07.css
images/kinglogo.png

(6) Example
example.html
js/example.js
js/jquery-1.11.0.js 
css/c07.css
images/kinglogo.png
